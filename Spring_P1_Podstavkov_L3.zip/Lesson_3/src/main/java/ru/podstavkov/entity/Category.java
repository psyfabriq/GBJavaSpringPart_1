package ru.podstavkov.entity;

import javax.persistence.Entity;

@Entity
public class Category extends AbstractEntity {
	// Variables inside AbstractEntity
}
