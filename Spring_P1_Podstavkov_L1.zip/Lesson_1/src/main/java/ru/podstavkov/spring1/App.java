package ru.podstavkov.spring1;

public class App {

}
